// Codemickey Assistance — JavaScript Functionality

// Initialize courses grid on page load
document.addEventListener('DOMContentLoaded', function() {
    displayCourses(coursesDatabase);
    setupEventListeners();
});

// Setup event listeners for filters
function setupEventListeners() {
    document.getElementById('courseSearch').addEventListener('input', filterCourses);
    document.getElementById('clusterFilter').addEventListener('change', filterCourses);
    document.getElementById('pointsFilter').addEventListener('change', filterCourses);
}

// Display courses in grid
function displayCourses(courses) {
    const coursesGrid = document.getElementById('coursesGrid');
    coursesGrid.innerHTML = '';
    
    if (courses.length === 0) {
        coursesGrid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #999;">No courses found. Try adjusting your filters.</p>';
        return;
    }
    
    courses.forEach(course => {
        const courseCard = document.createElement('div');
        courseCard.className = 'course-card';
        courseCard.innerHTML = `
            <span class="course-cluster">Cluster ${course.cluster}</span>
            <h3>${course.name}</h3>
            <p><strong>University:</strong> ${course.university}</p>
            <p><strong>Code:</strong> ${course.code}</p>
            <p><strong>Field:</strong> ${course.field}</p>
            <p><strong>Subjects Required:</strong> ${course.subjects.join(', ')}</p>
            <div class="course-points">
                <span>Min. Points:</span>
                <span class="points-badge">${course.minPoints}+</span>
            </div>
        `;
        coursesGrid.appendChild(courseCard);
    });
}

// Filter courses based on search and filters
function filterCourses() {
    const searchTerm = document.getElementById('courseSearch').value.toLowerCase();
    const clusterFilter = document.getElementById('clusterFilter').value;
    const pointsFilter = document.getElementById('pointsFilter').value;
    
    let filtered = coursesDatabase.filter(course => {
        // Search filter
        const matchesSearch = course.name.toLowerCase().includes(searchTerm) ||
                             course.code.includes(searchTerm) ||
                             course.university.toLowerCase().includes(searchTerm);
        
        // Cluster filter
        const matchesCluster = !clusterFilter || course.cluster == clusterFilter;
        
        // Points filter
        let matchesPoints = true;
        if (pointsFilter) {
            const minRequired = parseInt(pointsFilter);
            matchesPoints = course.minPoints >= minRequired;
        }
        
        return matchesSearch && matchesCluster && matchesPoints;
    });
    
    displayCourses(filtered);
}

// Calculate cluster points
function calculatePoints() {
    const grades = [];
    
    for (let i = 1; i <= 4; i++) {
        const gradeSelect = document.getElementById(`grade${i}`);
        if (gradeSelect.value) {
            grades.push(parseInt(gradeSelect.value));
        }
    }
    
    if (grades.length < 4) {
        alert('Please select all 4 subjects and grades.');
        return;
    }
    
    // Calculate total points
    const totalPoints = grades.reduce((a, b) => a + b, 0);
    
    // Display result
    const resultDiv = document.getElementById('calculatorResult');
    const pointsValue = document.getElementById('pointsValue');
    const pointsInterpretation = document.getElementById('pointsInterpretation');
    
    pointsValue.textContent = totalPoints;
    
    // Interpretation
    let interpretation = '';
    if (totalPoints >= 40) {
        interpretation = '🎯 Excellent! You qualify for highly competitive programmes like Law, Medicine, and Engineering.';
    } else if (totalPoints >= 35) {
        interpretation = '✓ Very Good! You qualify for competitive programmes like Engineering, Actuarial Science, and advanced courses.';
    } else if (totalPoints >= 30) {
        interpretation = '✓ Good! You qualify for most business, IT, and professional programmes.';
    } else if (totalPoints >= 25) {
        interpretation = '✓ Fair! You qualify for education, agriculture, and general degree programmes.';
    } else {
        interpretation = 'You may qualify for entry-level programmes. Consider exploring diploma options.';
    }
    
    pointsInterpretation.textContent = interpretation;
    
    // Show recommended courses
    showRecommendedCourses(totalPoints);
    
    resultDiv.style.display = 'block';
    resultDiv.scrollIntoView({ behavior: 'smooth' });
}

// Show recommended courses based on cluster points
function showRecommendedCourses(points) {
    const recommendedDiv = document.getElementById('recommendedCourses');
    
    // Filter courses that match the points
    const recommended = coursesDatabase.filter(course => {
        return course.minPoints <= points && course.minPoints >= (points - 5);
    }).slice(0, 5);
    
    if (recommended.length > 0) {
        let html = '<h4 style="margin-top: 2rem; margin-bottom: 1rem;">Recommended Courses for You:</h4>';
        html += '<div style="display: grid; gap: 1rem;">';
        
        recommended.forEach(course => {
            html += `
                <div style="background: rgba(0, 82, 204, 0.1); padding: 1rem; border-radius: 4px; border-left: 3px solid #0052CC;">
                    <strong>${course.name}</strong><br>
                    <small>${course.university} | Cluster ${course.cluster} | Min. ${course.minPoints}+ points</small>
                </div>
            `;
        });
        
        html += '</div>';
        recommendedDiv.innerHTML = html;
    }
}

// Contact support
function contactSupport() {
    window.location.href = 'https://wa.me/254769238470?text=Hello%20Codemickey%20Assistance%2C%20I%20need%20help%20with%20my%20KUCCPS%20application.';
}

// Submit application form
function submitForm(event) {
    event.preventDefault();
    
    const form = event.target;
    const name = form.elements[0].value;
    const email = form.elements[1].value;
    const phone = form.elements[2].value;
    const message = form.elements[3].value;
    
    // Create WhatsApp message
    const whatsappMessage = `Hello Codemickey Assistance,\n\nI would like to request assisted application service.\n\nName: ${name}\nEmail: ${email}\nPhone: ${phone}\n\nDetails: ${message}`;
    
    const encodedMessage = encodeURIComponent(whatsappMessage);
    window.location.href = `https://wa.me/254769238470?text=${encodedMessage}`;
}

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        const href = this.getAttribute('href');
        if (href !== '#' && document.querySelector(href)) {
            e.preventDefault();
            document.querySelector(href).scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});

// Add scroll animation for elements
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

document.querySelectorAll('.step, .pricing-card, .course-card').forEach(el => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(20px)';
    el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(el);
});
