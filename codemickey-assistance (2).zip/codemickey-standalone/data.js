// Codemickey Assistance — KUCCPS Courses Database
// Real data from KUCCPS 2025/2026 placement cycle

const coursesDatabase = [
    // Cluster 1 - Law
    {
        id: 1,
        cluster: 1,
        name: "Bachelor of Laws (LLB)",
        code: "1000101",
        university: "University of Nairobi",
        minPoints: 42,
        subjects: ["English", "Mathematics", "History", "Geography"],
        field: "Law"
    },
    
    // Cluster 2 - Business & Hospitality
    {
        id: 2,
        cluster: 2,
        name: "Bachelor of Commerce",
        code: "1000201",
        university: "Kenyatta University",
        minPoints: 32,
        subjects: ["English", "Mathematics", "Business Studies", "Economics"],
        field: "Business"
    },
    {
        id: 3,
        cluster: 2,
        name: "Bachelor of Business Administration",
        code: "1000202",
        university: "JKUAT",
        minPoints: 30,
        subjects: ["English", "Mathematics", "Business Studies", "Any"],
        field: "Business"
    },
    {
        id: 4,
        cluster: 2,
        name: "Bachelor of Hospitality Management",
        code: "1000203",
        university: "Kenya Utalii College",
        minPoints: 26,
        subjects: ["English", "Any", "Any", "Any"],
        field: "Hospitality"
    },
    {
        id: 5,
        cluster: 2,
        name: "Bachelor of Accounting",
        code: "1000204",
        university: "Strathmore University",
        minPoints: 35,
        subjects: ["English", "Mathematics", "Business Studies", "Economics"],
        field: "Business"
    },
    
    // Cluster 5 - Engineering
    {
        id: 6,
        cluster: 5,
        name: "Bachelor of Science in Civil Engineering",
        code: "1000501",
        university: "JKUAT",
        minPoints: 38,
        subjects: ["English", "Mathematics", "Physics", "Chemistry"],
        field: "Engineering"
    },
    {
        id: 7,
        cluster: 5,
        name: "Bachelor of Science in Mechanical Engineering",
        code: "1000502",
        university: "University of Nairobi",
        minPoints: 40,
        subjects: ["English", "Mathematics", "Physics", "Chemistry"],
        field: "Engineering"
    },
    {
        id: 8,
        cluster: 5,
        name: "Bachelor of Science in Electrical Engineering",
        code: "1000503",
        university: "Technical University of Kenya",
        minPoints: 39,
        subjects: ["English", "Mathematics", "Physics", "Chemistry"],
        field: "Engineering"
    },
    {
        id: 9,
        cluster: 5,
        name: "Bachelor of Science in Chemical Engineering",
        code: "1000504",
        university: "JKUAT",
        minPoints: 37,
        subjects: ["English", "Mathematics", "Chemistry", "Physics"],
        field: "Engineering"
    },
    {
        id: 10,
        cluster: 5,
        name: "Bachelor of Science in Software Engineering",
        code: "1000505",
        university: "Multimedia University",
        minPoints: 35,
        subjects: ["English", "Mathematics", "Physics", "Computer Studies"],
        field: "Engineering"
    },
    
    // Cluster 7 - Computing & IT
    {
        id: 11,
        cluster: 7,
        name: "Bachelor of Science in Computer Science",
        code: "1000701",
        university: "University of Nairobi",
        minPoints: 36,
        subjects: ["English", "Mathematics", "Physics", "Computer Studies"],
        field: "Computing"
    },
    {
        id: 12,
        cluster: 7,
        name: "Bachelor of Science in Information Technology",
        code: "1000702",
        university: "Kenyatta University",
        minPoints: 32,
        subjects: ["English", "Mathematics", "Computer Studies", "Any"],
        field: "Computing"
    },
    {
        id: 13,
        cluster: 7,
        name: "Bachelor of Science in Cybersecurity",
        code: "1000703",
        university: "Mount Kenya University",
        minPoints: 30,
        subjects: ["English", "Mathematics", "Computer Studies", "Physics"],
        field: "Computing"
    },
    
    // Cluster 10 - Actuarial & Accounting
    {
        id: 14,
        cluster: 10,
        name: "Bachelor of Science in Actuarial Science",
        code: "1001001",
        university: "University of Nairobi",
        minPoints: 41,
        subjects: ["English", "Mathematics", "Physics", "Economics"],
        field: "Actuarial"
    },
    {
        id: 15,
        cluster: 10,
        name: "Bachelor of Science in Accountancy",
        code: "1001002",
        university: "Kenyatta University",
        minPoints: 33,
        subjects: ["English", "Mathematics", "Business Studies", "Economics"],
        field: "Accounting"
    },
    {
        id: 16,
        cluster: 10,
        name: "Bachelor of Science in Economics",
        code: "1001003",
        university: "Maseno University",
        minPoints: 28,
        subjects: ["English", "Mathematics", "Economics", "Geography"],
        field: "Economics"
    },
    
    // Cluster 13 - Medicine & Health
    {
        id: 17,
        cluster: 13,
        name: "Bachelor of Medicine, Bachelor of Surgery (MBChB)",
        code: "1001301",
        university: "University of Nairobi",
        minPoints: 45,
        subjects: ["English", "Mathematics", "Biology", "Chemistry"],
        field: "Medicine"
    },
    {
        id: 18,
        cluster: 13,
        name: "Bachelor of Science in Nursing",
        code: "1001302",
        university: "Kenyatta University",
        minPoints: 32,
        subjects: ["English", "Biology", "Chemistry", "Any"],
        field: "Health"
    },
    {
        id: 19,
        cluster: 13,
        name: "Bachelor of Science in Pharmacy",
        code: "1001303",
        university: "University of Nairobi",
        minPoints: 40,
        subjects: ["English", "Mathematics", "Chemistry", "Biology"],
        field: "Health"
    },
    {
        id: 20,
        cluster: 13,
        name: "Bachelor of Science in Public Health",
        code: "1001304",
        university: "JKUAT",
        minPoints: 30,
        subjects: ["English", "Biology", "Chemistry", "Any"],
        field: "Health"
    },
    {
        id: 21,
        cluster: 13,
        name: "Bachelor of Science in Physiotherapy",
        code: "1001305",
        university: "Kenyatta University",
        minPoints: 28,
        subjects: ["English", "Biology", "Chemistry", "Physics"],
        field: "Health"
    },
    
    // Cluster 19 - Education
    {
        id: 22,
        cluster: 19,
        name: "Bachelor of Education (Science)",
        code: "1001901",
        university: "Kenyatta University",
        minPoints: 26,
        subjects: ["English", "Mathematics", "Physics", "Chemistry"],
        field: "Education"
    },
    {
        id: 23,
        cluster: 19,
        name: "Bachelor of Education (Arts)",
        code: "1001902",
        university: "University of Nairobi",
        minPoints: 24,
        subjects: ["English", "History", "Geography", "Any"],
        field: "Education"
    },
    {
        id: 24,
        cluster: 19,
        name: "Bachelor of Education (Mathematics)",
        code: "1001903",
        university: "Maseno University",
        minPoints: 25,
        subjects: ["English", "Mathematics", "Physics", "Any"],
        field: "Education"
    },
    
    // Cluster 3 - Social Sciences
    {
        id: 25,
        cluster: 3,
        name: "Bachelor of Arts",
        code: "1000301",
        university: "University of Nairobi",
        minPoints: 22,
        subjects: ["English", "History", "Geography", "Any"],
        field: "Social Sciences"
    },
    {
        id: 26,
        cluster: 3,
        name: "Bachelor of Journalism",
        code: "1000302",
        university: "Kenyatta University",
        minPoints: 24,
        subjects: ["English", "Any", "Any", "Any"],
        field: "Media"
    },
    
    // Cluster 8 - Agribusiness
    {
        id: 27,
        cluster: 8,
        name: "Bachelor of Science in Agriculture",
        code: "1000801",
        university: "Egerton University",
        minPoints: 26,
        subjects: ["English", "Biology", "Chemistry", "Any"],
        field: "Agriculture"
    },
    {
        id: 28,
        cluster: 8,
        name: "Bachelor of Science in Agribusiness",
        code: "1000802",
        university: "JKUAT",
        minPoints: 24,
        subjects: ["English", "Biology", "Mathematics", "Any"],
        field: "Agriculture"
    },
    
    // Cluster 9 - General Science
    {
        id: 29,
        cluster: 9,
        name: "Bachelor of Science in Physics",
        code: "1000901",
        university: "University of Nairobi",
        minPoints: 34,
        subjects: ["English", "Mathematics", "Physics", "Chemistry"],
        field: "Science"
    },
    {
        id: 30,
        cluster: 9,
        name: "Bachelor of Science in Chemistry",
        code: "1000902",
        university: "Kenyatta University",
        minPoints: 32,
        subjects: ["English", "Mathematics", "Chemistry", "Physics"],
        field: "Science"
    },
    {
        id: 31,
        cluster: 9,
        name: "Bachelor of Science in Biology",
        code: "1000903",
        university: "Maseno University",
        minPoints: 28,
        subjects: ["English", "Biology", "Chemistry", "Any"],
        field: "Science"
    },
];

// Grade to Points Conversion
const gradePoints = {
    12: 'A',
    11: 'A-',
    10: 'B+',
    9: 'B',
    8: 'B-',
    7: 'C+',
    6: 'C',
    5: 'C-',
    4: 'D+',
    3: 'D'
};

// Cluster Information
const clusterInfo = {
    1: { name: "Law", minPoints: 40, description: "Bachelor of Laws and related programmes" },
    2: { name: "Business, Hospitality & Related", minPoints: 26, description: "Commerce, Business Administration, Hospitality" },
    3: { name: "Social Sciences, Media Studies, Fine Arts", minPoints: 20, description: "Arts, Journalism, Social Sciences" },
    5: { name: "Engineering, Engineering Technology", minPoints: 35, description: "Civil, Mechanical, Electrical, Chemical Engineering" },
    7: { name: "Computing, IT & Related", minPoints: 28, description: "Computer Science, IT, Cybersecurity" },
    8: { name: "Agribusiness & Related", minPoints: 22, description: "Agriculture, Agribusiness" },
    9: { name: "General Science, Biological Sciences", minPoints: 26, description: "Physics, Chemistry, Biology" },
    10: { name: "Actuarial Science, Accountancy, Mathematics", minPoints: 30, description: "Actuarial Science, Accounting, Economics" },
    13: { name: "Medicine, Health, Veterinary Medicine", minPoints: 28, description: "Medicine, Nursing, Pharmacy, Public Health" },
    19: { name: "Education & Related", minPoints: 22, description: "Bachelor of Education programmes" }
};

// Universities
const universities = [
    "University of Nairobi",
    "Kenyatta University",
    "JKUAT",
    "Egerton University",
    "Maseno University",
    "Moi University",
    "Technical University of Kenya",
    "Strathmore University",
    "Mount Kenya University",
    "Multimedia University",
    "Kenya Utalii College"
];
